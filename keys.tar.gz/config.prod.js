module.exports = {
    SESSION_SECRET: process.env.SESSION_SECRET,
    MONGODB_URL: process.env.MONGODB_URL,
    SENDGRID_API: process.env.SENDGRID_API,
    BASE_URL: process.env.BASE_URL,
    EMAIL: process.env.EMAIL
};