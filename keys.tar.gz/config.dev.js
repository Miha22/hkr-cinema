module.exports = {
    SESSION_SECRET: 'some secret ok',
    MONGODB_URL: 'mongodb+srv://cluster0.7yryy.mongodb.net/myFirstDatabase?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority',
    SENDGRID_API: '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',
    BASE_URL: 'http://localhost:3000',
    EMAIL: 'team@mysport-community.com',
    PORT: 3000
};